🚲 Bike Sharing Analytics Dashboard

Proyek ini merupakan dashboard interaktif untuk menganalisis data penyewaan sepeda berdasarkan berbagai faktor seperti cuaca, musim, dan waktu. Dashboard ini dibangun menggunakan Streamlit untuk mempermudah eksplorasi data secara dinamis.

📂 Struktur Proyek

/dashboard: Berisi file utama aplikasi dan dataset yang telah diproses.
dashboard.py: Kode utama aplikasi Streamlit.
all_data_clean.csv: Dataset hasil cleaning.

/data: Berisi dataset mentah (day.csv dan hour.csv).

notebook.ipynb: Notebook untuk proses analisis data lengkap.

requirements.txt: Daftar pustaka (library) Python yang diperlukan.

README.md: Dokumentasi proyek.

🚀 Langkah-Langkah Menjalankan Dashboard

Ikuti panduan berikut untuk menjalankan dashboard di perangkat lokal Anda:

1. Persiapan Environment

Disarankan untuk menggunakan virtual environment agar tidak terjadi konflik antar pustaka. Buka terminal atau command prompt, lalu jalankan perintah berikut:

# Membuat virtual environment bernama 'venv'
python -m venv venv

# Mengaktifkan virtual environment
# Untuk Windows:
venv\Scripts\activate
# Untuk Mac/Linux:
source venv/bin/activate


2. Instalasi Library

Setelah environment aktif, instal semua pustaka yang dibutuhkan menggunakan file requirements.txt:

pip install -r requirements.txt


3. Menjalankan Dashboard Streamlit

Pastikan Anda berada di direktori utama proyek, lalu jalankan perintah berikut:
cd dashboard
streamlit run dashboard/dashboard.py

Atau jika Anda tetap di folder utama:
streamlit run dashboard/dashboard.py

Aplikasi bisa dibuka pada browser Anda di alamat https://bike-sharing-analysis-widya.streamlit.app/